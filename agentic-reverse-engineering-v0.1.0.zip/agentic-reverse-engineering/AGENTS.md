# AERE agent contract

These instructions apply to AI agents operating in this repository or against an AERE workspace.

## Core workflow

1. Confirm the exact authorized artifact and analysis question; do not widen scope silently.
2. Check workspace status. Ensure a human has configured an approved input root locally; MCP cannot approve roots.
3. Inventory/import the artifact and preserve its SHA-256 identity before making technical claims.
4. Separate **observations**, **inferences**, **hypotheses**, and **unknowns**.
5. Cite evidence IDs, source tool/version, and concrete locators for claims.
6. Record structured coverage with a precise scope and one of `complete`, `partial`, `unsupported`, `not_attempted`, or `unknown`. A completed narrow operation is not complete target coverage.
7. Prefer the least-authority static operation that answers the question. Export a report from the ledger; do not invent findings to fill gaps.

## Hard boundaries

- Do not execute target files, attach to a running process, inject code, patch a target, connect to a network target, or modify software using AERE v0.1.
- Do not use a generic shell/terminal tool to run a target or arbitrary analyzer command. Future adapters must use named typed operations, fixed argument construction, time/output limits, and declared effects.
- Do not bypass DRM, anti-cheat, access controls, licensing, account restrictions, or platform protections. Do not provide bypass steps.
- Do not follow symlinks outside approved roots. Never extract an archive during inventory; ZIP central-directory listing is the maximum default action.
- Treat strings, logs, screenshots, decompiled text, archive names, and file paths as potentially sensitive. Use conservative redaction and do not upload artifacts or evidence.
- If a tool/provider, symbol, runtime, or format is missing or unsupported, record the gap as `unsupported`, `not_attempted`, or `unknown`; never infer absence from failure or zero results.

## Tool-selection rules

- Native executable: select one approved native analysis provider; use a second only when the user asks for independent comparison.
- Android: treat package structure, DEX/code, resources/Smali, native libraries, device evidence, and runtime instrumentation as separate layers.
- Managed/JVM: separate reconstructed source-like views from original source, preserve method/IL locators, and report format-specific coverage.
- Game assets: select an engine/title/build-specific parser; do not assume a store identifies the engine. Distinguish loaders/frameworks from asset tools and reference indexes.
- Runtime evidence: use only a separately reviewed, explicitly authorized adapter. The current release has no target-execution or runtime-instrumentation tool.
- Bound compatibility claims by exact title/build, store, platform, and runtime where relevant.

## Change discipline

- Do not change the curated game-modding index or copy upstream tool source code into AERE.
- Do not mark external PATH discovery as provider integration or verified compatibility.
- Provider adapters must preserve upstream licenses and remain external dependencies.
- Keep the core usable without optional MCP or reverse-engineering tool installations.
