from __future__ import annotations

import asyncio
import json
import os
import sys
from pathlib import Path

import pytest


def test_optional_stdio_mcp_surface(tmp_path: Path):
    pytest.importorskip("mcp")
    from mcp import ClientSession, StdioServerParameters
    from mcp.client.stdio import stdio_client

    project_src = str(Path(__file__).resolve().parents[1] / "src")
    env = {**os.environ, "PYTHONPATH": project_src}
    home = tmp_path / "mcp-workspace"
    params = StdioServerParameters(
        command=sys.executable,
        args=["-m", "aere.cli", "--home", str(home), "mcp"],
        env=env,
    )

    async def exercise():
        async with stdio_client(params) as (read, write):
            async with ClientSession(read, write) as session:
                await session.initialize()
                listed = await session.list_tools()
                names = {tool.name for tool in listed.tools}
                assert {"workspace_status", "import_artifact", "record_evidence", "record_coverage", "export_run_json"} <= names
                assert "allow_input_root" not in names
                status_result = await session.call_tool("workspace_status", {})
                status = json.loads(status_result.content[0].text)
                assert status["home"] == str(home)
                assert status["allowed_root_count"] == 0

    asyncio.run(exercise())
