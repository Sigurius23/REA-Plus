# AERE Workbench

**AERE** means **Agentic Evidence-first Reverse Engineering**. It is a local workbench for controlled software investigation: approved-root artifact intake, hash-bound identity, bounded static triage, a provenance-aware evidence ledger, structured coverage reporting, and a typed CLI/MCP surface.

> **Status: v0.1 safe foundation — not a universal reverse-engineering platform.** Shipped analysis is deliberately narrow: SHA-256 import/inventory, conservative format candidates, bounded printable-ASCII strings, ZIP central-directory metadata, evidence/coverage records, and JSON/Markdown reports. There is no integrated deep disassembler/decompiler, Android decoder, game-asset parser, or runtime observer. The provider API is an extension contract, not a claim that external tools are connected.

This repository is **separate from** `game-modding-research-index`. It does not modify that catalog, copy upstream analyzer source code, or use submodules.

## Principles

- **Evidence before prose:** observations, inferences, hypotheses, and unknowns are distinct, artifact-linked records.
- **Coverage is first-class:** every coverage statement has an explicit scope, status, provider/operation, version when known, optional counts, exclusions, and limitations. “Complete” means complete only for that stated operation and scope.
- **One core:** CLI and MCP use the same workspace, SQLite ledger, artifact checks, limits, and reports.
- **Least authority:** v0.1 does not execute target files, accept generic shell commands, access a network target, attach to a process, inject code, patch targets, or extract archives.
- **Explicit extensibility:** provider objects must be explicitly registered by a trusted host; there is no automatic plugin import or “tool found on PATH = adapter works” assumption.
- **Honest compatibility:** report exact title/build/platform/runtime constraints where relevant. Storefront, engine, filename, and extension alone do not establish compatibility.

## Quick start

Python 3.11+ is required. The core uses only the standard library. The optional MCP interface uses the official Python MCP SDK.

```bash
python -m venv .venv
# macOS/Linux
. .venv/bin/activate
# Windows PowerShell: .venv\Scripts\Activate.ps1
python -m pip install -e '.[dev,mcp]'

# Create a workspace and explicitly approve a local input directory.
aere --home ./.aere init --allow-root ./samples

# Read-only inventory, artifact registration, and provenance-bearing triage.
aere --home ./.aere inventory ./samples
aere --home ./.aere import ./samples/example.apk
# Copy the artifact_id returned by import into:
aere --home ./.aere triage sha256:REPLACE_WITH_64_HEX_DIGEST --include-strings --list-archive-members
```

An empty workspace approves no input roots. Add roots deliberately with `init --allow-root DIR` or `allow-root DIR`. MCP does **not** include a tool that can approve new roots; configure authority locally before connecting an agent. The database stores metadata and evidence under the workspace (`state.sqlite3`), not target bytes. No artifacts are copied into this repository.

## CLI

Pass `--home` before the command, or set `AERE_HOME`.

```text
aere [--home DIR] init [--allow-root DIR ...]
aere [--home DIR] status
aere [--home DIR] allow-root DIR
aere [--home DIR] providers
aere [--home DIR] inventory PATH
aere [--home DIR] import FILE
aere [--home DIR] artifacts [--limit N]
aere [--home DIR] artifact ARTIFACT_ID
aere [--home DIR] probe ARTIFACT_ID
aere [--home DIR] strings ARTIFACT_ID [--min-length N] [--limit N]
aere [--home DIR] archive-list ARTIFACT_ID [--limit N]
aere [--home DIR] triage ARTIFACT_ID [--include-strings] [--list-archive-members]
aere [--home DIR] run create ARTIFACT_ID --workflow NAME [--provider ID]
aere [--home DIR] run finish RUN_ID [--status complete|partial|failed|cancelled]
aere [--home DIR] evidence add RUN_ID --kind KIND --claim TEXT --tool ID ...
aere [--home DIR] evidence list RUN_ID
aere [--home DIR] coverage add RUN_ID --subject TEXT --status STATUS --scope TEXT --provider ID --operation ID ...
aere [--home DIR] coverage list RUN_ID
aere [--home DIR] report RUN_ID [--format json|markdown] [--out FILE]
aere [--home DIR] mcp
```

Machine-readable commands emit JSON to stdout; diagnostics go to stderr. Markdown reports are plain Markdown. `triage` creates a run and records evidence and coverage for the built-ins; deep analysis is explicitly recorded as unsupported. `probe`, `strings`, and `archive-list` re-hash registered files and fail if identity changed. Archive listing never extracts or decompresses members.

## MCP

Install the optional extra, configure approved roots locally, then register AERE as a local stdio MCP server:

```json
{
  "mcpServers": {
    "aere": {
      "command": "/absolute/path/to/.venv/bin/aere",
      "args": ["--home", "/absolute/path/to/.aere", "mcp"]
    }
  }
}
```

On Windows, use the absolute path to `.venv\\Scripts\\aere.exe`. The server exposes typed tools for status/provider discovery, bounded inventory/import/probe, strings/ZIP metadata, run/evidence/coverage management, and export. It does **not** expose root approval, shell, arbitrary commands, target execution, or process attachment.

## Shipped capabilities and limits

| Capability | v0.1 behavior | Boundaries |
|---|---|---|
| Artifact intake | SHA-256 content identity, stable-file check, metadata-only registration | One regular file under an approved root; no copy into repo |
| Inventory | Bounded recursive inventory, hashes, format candidates | No symlink traversal; bounded files/bytes/size; common generated directories skipped |
| Format probe | ELF, PE candidate, Mach-O, WASM, ZIP/APK/AAB/JAR and selected game-package candidates | Candidate classification is not proof of engine, loader, validity, or behavior |
| Strings | Bounded printable ASCII extraction with byte offsets and capped samples | Secret-like assignments/Bearer strings redacted; no UTF-16, semantic decoding, or reachability analysis |
| ZIP metadata | Bounded central-directory names/metadata and unsafe-path flags | Configurable member/byte caps; never decompresses or extracts members |
| Evidence ledger | Observation / inference / hypothesis / unknown, sources, locators, links, confidence, caveats | Agent-supplied confidence is not verification |
| Coverage ledger | Complete / partial / unsupported / not attempted / unknown, scope, provider/version, counts, limits | Missing coverage is never treated as a negative finding |
| Export | Bounded JSON evidence bundle and Markdown report | Absolute source paths and target bytes are omitted; likely secrets are conservatively redacted |
| MCP | Optional local stdio server over the same core | Requires an MCP-capable host; no model, harness, or analyzer is bundled |

## Provider extension boundary

- `src/aere/provider_api.py` defines typed manifests, named operations, hash-bound requests/results, evidence drafts, and coverage records.
- `ProviderRegistry` only accepts explicitly registered provider instances. It validates artifact identity, version, and declared operation.
- v0.1 ships **no external analyzer adapter**. `aere providers` reports installed tools as `discovered-not-integrated`; presence on `PATH` is not a connection or compatibility test.
- Provider adapters remain separate dependencies. Do not vendor or submodule Ghidra, IDA bridges, JADX, Apktool, ILSpy, game asset readers, or other upstream source.

Before a provider can be marked verified, see [`docs/provider-contract.md`](docs/provider-contract.md): real-tool tests, supported/unsupported format cases, time/output bounds, cancellation/cleanup, exact evidence offsets, and coverage reporting are required.

## Roadmaps and workflows

- [`docs/workflows/native-static.md`](docs/workflows/native-static.md) — narrow native static investigation.
- [`docs/workflows/android.md`](docs/workflows/android.md) — package, DEX, resources, native libraries, and device/runtime boundaries.
- [`docs/workflows/managed-and-jvm.md`](docs/workflows/managed-and-jvm.md) — .NET, JVM, Android DEX, Unity Mono/IL2CPP.
- [`docs/workflows/game-analysis.md`](docs/workflows/game-analysis.md) — code vs asset tools; exact title/build/store/platform/runtime boundaries.
- [`docs/workflows/firmware-and-embedded.md`](docs/workflows/firmware-and-embedded.md) — static firmware workflow and unsupported capabilities.
- [`docs/architecture.md`](docs/architecture.md), [`docs/safety-model.md`](docs/safety-model.md), [`docs/provider-contract.md`](docs/provider-contract.md), [`docs/roadmap.md`](docs/roadmap.md), and the [`evidence bundle JSON Schema`](schemas/evidence-bundle.v1.schema.json).
- [`skills/evidence-first-re/SKILL.md`](skills/evidence-first-re/SKILL.md) — reusable agent workflow.

## Development and verification

```bash
python -m pip install -e '.[dev]'
pytest -q
python -m compileall -q src tests
```

Tests use synthetic byte/ZIP fixtures in temporary directories; no real apps, games, executables, decompiled code, credentials, or game assets are shipped. The MCP integration test is skipped when the optional SDK is absent.

## License

MIT for AERE Workbench. External tools and future adapters retain their own licenses, terms, and compatibility constraints.
