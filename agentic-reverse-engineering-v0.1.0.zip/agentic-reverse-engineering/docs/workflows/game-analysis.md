# Workflow: Steam game analysis

## First principle

Steam is a distribution platform, not an engine. Do not choose a parser from the store alone. Identify the exact game build, executable/runtime, platform, and data files before selecting providers.

## Layers

1. Inventory the installed files and hash selected artifacts; exclude user data and unrelated files unless needed.
2. Identify likely engine/runtime from executable and package signatures; label the result as a candidate until corroborated.
3. Choose a **code** tool and an **asset/archive** tool separately:
   - Unity Mono: managed-code analysis + Unity asset reader.
   - Unity IL2CPP: metadata/code reconstruction + native analyzer + asset reader.
   - Unreal: archive/resource reader + native/managed analysis as needed.
   - Godot: project/PCK recovery tool + native analysis as needed.
   - Source 2: Valve resource reader + native analysis.
   - Other engines: use a verified title/version-specific parser or report the unsupported format.
4. For each extractor, record exact game/version/store/platform support. Do not extrapolate compatibility.
5. Keep mod loaders, runtime inspectors, managers, and asset editors distinct from read-only analysis tools.

## Current implementation

AERE v0.1 only provides safe inventory, format candidates, bounded strings, ZIP metadata, and evidence records. It does not parse proprietary game archives, run mods, merge game data, or test a game in process. For full game modding workflows, use a separate game-modding agent workflow and the target-specific tools; do not make AERE silently execute the game.
