# Workflow: Android package investigation

## Layers

- **Package inventory:** list APK/AAB entries and manifest candidates without extraction.
- **DEX code:** a verified JADX adapter and JDK are needed for Java-like method views.
- **Resources/Smali:** a verified Apktool adapter is a separate layer.
- **Device evidence:** ADB/log capture is a distinct opt-in provider and is not equivalent to static package analysis.
- **Native libraries:** `.so` files require a native analysis provider by ABI/architecture.
- **Runtime instrumentation:** not implemented in AERE v0.1; do not imply that ADB logs are Frida-style method tracing.

## Evidence rules

Record package SHA-256, split names, manifest/resource file offsets or paths, DEX method identifiers, ABI and library identity. Decompiled Java-like output is reconstructed and may be incomplete. Do not label it original Java/Kotlin source. Keep device logs/screenshots separate from static observations and record the device/emulator identity only if the user approved that collection.

## Current implementation

AERE v0.1 can identify ZIP/APK candidates and safely list ZIP central-directory metadata. It does not decode the Android manifest, DEX, resources, or inspect a device until a verified adapter is added.
