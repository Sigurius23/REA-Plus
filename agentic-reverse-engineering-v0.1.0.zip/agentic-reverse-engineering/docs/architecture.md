# Architecture

AERE separates local artifact authority, analysis provenance, and optional provider integrations. The CLI and stdio MCP façade call the same Python core and SQLite workspace.

```text
Agent harness / human operator
        │ typed commands/tools
        ▼
AERE CLI ─────── AERE stdio MCP (optional SDK)
        └──────────────┬───────────────┘
                       ▼
              Python standard-library core
              ├── approved-root artifact resolver + SHA-256 identity
              ├── SQLite artifact / run / evidence / coverage ledger
              ├── bounded built-ins: probe, ASCII strings, ZIP metadata
              └── typed Provider API (no automatic plugin loading)
                       │ explicit future registration only
                       ├── native static engines
                       ├── Android / managed / JVM tools
                       ├── title/build-specific game-asset readers
                       └── separately reviewed runtime observers
```

## Workspace and artifact identity

A workspace owns a local SQLite database and an explicit list of approved input roots. AERE registers file metadata and locations, not artifact copies. SHA-256 is the canonical content identity. Before and after bounded reads, AERE revalidates registered artifacts and fails closed if a source no longer matches.

## Runs

A run records an artifact identity, workflow, provider ID, bounded configuration, status, and timestamps. Status values are `created`, `complete`, `partial`, `failed`, or `cancelled`. Tool/provider versions are stored on evidence and coverage records where available; a run may include multiple providers.

## Evidence ledger

Evidence entries distinguish:

- `observation`: what a named tool directly returned;
- `inference`: an interpretation linked to observations;
- `hypothesis`: a testable but unverified idea;
- `unknown`: a fact not established by available evidence.

Each record can include a source tool/version, locator, data, same-artifact supporting evidence IDs, caveats, and agent-supplied confidence. Confidence is not a verification score.

## Structured coverage

Coverage is a first-class per-run record with a status (`complete`, `partial`, `unsupported`, `not_attempted`, or `unknown`), explicit scope, provider/operation/version, optional examined/total counts, exclusions, limitations, and notes. `complete` only means the stated operation completed within its declared scope; it does not mean the whole target was understood. Zero results, parser failures, unsupported regions, and unattempted layers must not be described as absence.

## Provider boundary

`src/aere/provider_api.py` defines typed manifests, named operations, requests, evidence drafts, results, and coverage. `ProviderRegistry` accepts explicitly registered trusted instances and validates that outputs match the requested artifact digest, provider version, and declared operation. It does not scan `PATH`, import arbitrary modules, or execute adapters. AERE v0.1 ships no external analyzer adapter; tool discovery is informational only.

A future adapter must use fixed, named operations, declare effect/format/platform bounds, enforce time/output limits, preserve provider versions and source locators, and pass real-tool integration tests. The core does not accept raw command strings.

## Trust boundaries

- CLI and MCP input is untrusted.
- Target files, archive names, and provider output are untrusted data, not instructions.
- Inputs must be under an approved root; symlinks are rejected.
- The core does not execute targets, extract archives, or access a network service.
- Evidence exports omit absolute source paths and apply conservative secret-like redaction.
