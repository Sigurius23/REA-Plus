# Roadmap and verification gates

AERE prioritizes trustworthy coverage and reproducibility over counting integrations. A capability is not “supported” until the adapter has been implemented and verified for a bounded target matrix.

## v0.1 — shipped safe foundation

- Approved local input roots, SHA-256 artifact identity, stable-file rechecks, SQLite provenance.
- Bounded directory inventory, conservative signature candidates, capped printable-ASCII strings, secret-like redaction, bounded ZIP central-directory metadata without extraction.
- Evidence and first-class coverage ledger, JSON/Markdown export, CLI, optional stdio MCP.
- Typed provider API and contract tests; **no external analyzer adapter**.

## Next: verified native static adapter

Priority is one read-only adapter with reproducible function/call/xref coverage rather than several thin bridges. Candidate providers include Ghidra, official Hex-Rays IDA MCP, Binary Ninja, Hopper, or radare2. Selection must respect licensing, host/edition availability, supported formats/architectures, API ownership, and actual testability.

Required slices:

1. Architecture, container, and loader validation with unsupported cases.
2. Function inventory and analysis completeness (including unresolved regions).
3. Named function, call-site, reference, import/export, and string operations with stable addresses/locators.
4. Disassembly/decompiler output captured as reconstructed views, with exact tool/version/settings.
5. Static evidence linked to an operation-level coverage record; zero results cannot imply absence without adequate scope.
6. Actual-tool tests, malformed/large file limits, timeout/cancellation, changed-input checks, CLI/MCP parity, and report schema validation.

## Then: layered managed and Android providers

- Android package/container inventory, manifest/resources, Smali/DEX and native `.so` analysis are separate operations.
- JADX, Apktool, JDK/ADB and optional device evidence must not be collapsed into a single “Android supported” flag.
- .NET, JVM, Unity Mono, and IL2CPP each need distinct format/build coverage. Decompiler output is not original source.
- Record exact OS, app/game build, ABI/architecture, tool versions, licenses, and known unsupported constructs.

## Then: game asset parsers by engine/build

Implement asset providers only for stated format/build families, and keep asset parsing distinct from code analysis, mod loaders/frameworks, runtime inspectors, editors, and discovery/reference indexes. Steam/store presence alone never selects an engine or establishes compatibility.

## Separate review: runtime evidence

Any future runtime provider requires a separate threat/authority review, explicit user opt-in, user-owned test process, isolated lab target, limited lifetime/output, clear stop/cleanup semantics, and non-bypass use. No runtime permission is inherited from static-analysis approval. Existing-process attachment, anti-cheat interaction, protection bypass, target writes, or network access are not part of routine roadmap work.

## Release gate

For every operation, publish a testable support row: provider/version, artifact family, architecture, OS, title/build/store/runtime constraints where relevant, operation, effects, coverage test, and limitations. “Available on PATH,” “works on one sample,” or a model-generated explanation is not verification.
