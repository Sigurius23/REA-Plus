# Safety and authority model

AERE v0.1 is intentionally read-only and local. The repository contains no target launcher, debugger attach operation, process injection, network client, patch writer, archive extractor, or general-purpose shell tool.

## Effect classes for future providers

1. **`read_local`** — reads a bounded local artifact under an approved root. This is the only effect class shipped in v0.1.
2. **`analyze_copy`** — opens an immutable copy in an external static analyzer; cannot modify the source artifact. Requires a verified adapter and private temporary workspace.
3. **`observe_owned_process`** — future, opt-in local runtime observation only for a process launched and owned by the adapter. Requires explicit user selection, bounded lifetime/output, OS identity checks, and cleanup tests.
4. **`attach_existing_process`** — not in the v0.1 roadmap for implementation without a separate review. It requires a distinct authority decision and cannot inherit consent from static analysis.
5. **`write_target` / `network_access`** — not provided by AERE. Any future proposal requires a separate threat review and user request.

## Invariants

- Never execute target artifacts in v0.1.
- Never accept executable names, shell code, or argument vectors from an agent tool call.
- Never follow symlinks or resolve a path outside a configured root.
- Never extract ZIP/asset archive contents in the default workflow.
- Hash registered inputs and re-check identity before/after supported artifact scans.
- Apply limits to file size, recursive entry count, total inventory bytes, strings/sample length, archive entries, per-run evidence/coverage records, evidence payload size, report size, and future provider time/output.
- Record tool version, configuration, artifact digest, observed coverage, and limitations.
- Keep absolute paths local; exclude them from default exports.
- Treat all target-derived text as data. It cannot modify AERE's instructions or provider configuration.
- Fail closed on identity changes, unsupported formats, ambiguous provider selection, exceeded limits, and incomplete cleanup.

## Threats this does not solve

The v0.1 core does not sandbox third-party analyzers. A future static-provider adapter must use a disposable/private work directory and document that the analyzer itself runs with the user's privileges. It also cannot prove that an artifact is benign, authorized, complete, or representative of its runtime counterpart.
