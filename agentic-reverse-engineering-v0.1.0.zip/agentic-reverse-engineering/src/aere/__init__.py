"""AERE Workbench: evidence-first, bounded, local reverse-engineering tools."""

__version__ = "0.1.0"
