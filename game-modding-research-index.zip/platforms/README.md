# Platform-specific scope notes

These pages supplement the catalog's resource categories with platform-focused coverage boundaries. They summarize platform coverage and documented tool roles.

- [Android](android/README.md) — developer-integrated UGC examples plus selected app-analysis references for static inspection, automated triage, and runtime observation; no general app-modification API is established.
